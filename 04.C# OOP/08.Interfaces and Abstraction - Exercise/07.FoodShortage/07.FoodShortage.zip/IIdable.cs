﻿namespace _07.FoodShortage
{
    public interface IIdable
    {
        string Id { get; }
    }
}
