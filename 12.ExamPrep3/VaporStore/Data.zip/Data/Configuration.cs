﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
            @"Server=DESKTOP-4PCJT2Q\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}