﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString => "Server=DESKTOP-4PCJT2Q\\SQLEXPRESS;Database=BookShop;Integrated Security=True;";
    }
}
