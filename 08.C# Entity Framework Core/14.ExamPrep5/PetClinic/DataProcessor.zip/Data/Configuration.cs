﻿namespace PetClinic.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-4PCJT2Q\SQLEXPRESS;Database=PetClinic;Trusted_Connection=True";
    }
}
