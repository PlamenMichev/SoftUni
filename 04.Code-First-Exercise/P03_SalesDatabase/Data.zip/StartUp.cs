﻿namespace P03_SalesDatabase
{
    using P03_SalesDatabase.Data;
    using Microsoft.EntityFrameworkCore;

    class StartUp
    {
        static void Main(string[] args)
        {
        }
    }
}
