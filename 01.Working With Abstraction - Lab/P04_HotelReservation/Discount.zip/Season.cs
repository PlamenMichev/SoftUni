﻿namespace P04_HotelReservation
{
    public enum Season
    {
        Autumn = 1,
        Spring,
        Winter,
        Summer
    }
}
