﻿namespace P04_HotelReservation
{
    public enum Discount
    {
        None,
        SecondVisit = 10,
        VIP = 20
    }
}
