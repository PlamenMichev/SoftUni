﻿namespace _01.LoggerLibrary
{
    public interface ILayout
    {
        string Format { get; }
    }
}
