﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;

namespace _05.DateModifier
{
    public class DateModifier
    {
        private double difference;

        public double Difference
        {
            get => this.difference;
            set => this.difference = value;
        }

        public double CalculatesDifference(string firstDate, string secDate)
        {
            DateTime firstDateAsDateTime = DateTime.ParseExact(firstDate, "yyyy MM dd", CultureInfo.InvariantCulture);
            DateTime secDateAsDateTime = DateTime.ParseExact(secDate, "yyyy MM dd", CultureInfo.InvariantCulture);
            double difference = (firstDateAsDateTime - secDateAsDateTime).TotalDays;

            return difference;
        }
    }
}
