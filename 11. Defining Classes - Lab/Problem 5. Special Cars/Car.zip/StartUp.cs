﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Tire[]> tires = new List<Tire[]>();
            List<Engine> engines = new List<Engine>();
            List<Car> cars = new List<Car>();
            List<Car> specialCars = new List<Car>();

            while (true)
            {
                string input = Console.ReadLine();
                if (input == "No more tires")
                {
                    break;
                }

                string[] tokens = input
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries);

                var currentTires = new Tire[4]
                {
                    new Tire(int.Parse(tokens[0]), double.Parse(tokens[1])), 
                    new Tire(int.Parse(tokens[2]), double.Parse(tokens[3])),
                    new Tire(int.Parse(tokens[4]), double.Parse(tokens[5])),
                    new Tire(int.Parse(tokens[6]), double.Parse(tokens[7])),
                };

                tires.Add(currentTires);
            }

            while (true)
            {
                string input = Console.ReadLine();
                if (input == "Engines done")
                {
                    break;
                }

                string[] tokens = input
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries);

                var currentEngine = new Engine(int.Parse(tokens[0]), double.Parse(tokens[1]));
                engines.Add(currentEngine);
            }

            while (true)
            {
                string input = Console.ReadLine();

                if (input == "Show special")
                {
                    break;
                }

                string[] tokens = input
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string make = tokens[0];
                string model = tokens[1];
                int year = int.Parse(tokens[2]);
                double fuelQuantity = double.Parse(tokens[3]);
                double fuelConsumption = double.Parse(tokens[4]);
                int engineIndex = int.Parse(tokens[5]);
                int tiresIndex = int.Parse(tokens[6]);

                var currentCar = new Car(make, model, year, fuelQuantity, fuelConsumption, engines[engineIndex], tires[tiresIndex]);

                bool isSpecial = IsSpecial(currentCar);

                if (isSpecial)
                {
                    currentCar.Drive(20);
                    specialCars.Add(currentCar);
                }
            }

            foreach (var car in specialCars)
            {
                StringBuilder sb = new StringBuilder();
                sb.AppendLine($"Make: {car.Make}");
                sb.AppendLine($"Model: {car.Model}");
                sb.AppendLine($"Year: {car.Year}");
                sb.AppendLine($"HorsePowers: {car.Engine.HorsePower}");
                sb.Append($"FuelQuantity: {car.FuelQuantity}");
                Console.WriteLine(sb.ToString());               
            }
        }

        public static bool IsSpecial(Car car)
        {
            bool isSpecial = false;

            if (car.Year >= 2017 && car.Engine.HorsePower >= 330 && car.Tires.Select(x => x.Pressure).Sum() >= 9 
                && car.Tires.Select(x => x.Pressure).Sum() <= 10)
            {
                isSpecial = true;
            }

            return isSpecial;
        }
    }
}
