﻿using System;
using Problem_2._Car_Extension;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
