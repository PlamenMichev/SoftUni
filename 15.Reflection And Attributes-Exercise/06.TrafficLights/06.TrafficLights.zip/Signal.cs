﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06.TrafficLights
{
    public enum Signal
    {
        Red = 1,
        Green = 2,
        Yellow = 3,
    }
}
