﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.InfernoInfinity.Enums
{
    public enum LevelOfRearity
    {
        Common = 1,
        Uncommon = 2,
        Rare = 3,
        Epic = 5
    }
}
