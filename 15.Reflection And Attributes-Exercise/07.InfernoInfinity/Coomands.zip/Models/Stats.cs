﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.InfernoInfinity.Models
{
    public class Stats
    {
        public Stats()
        {
            
        }

        public int MinDamage { get; set; }

        public int MaxDamage { get; set; }

        public int NumberOfSockets { get; set; }
    }
}
