﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _08.MilitaryElite
{
    public interface IPrivate
    {
        decimal Salary { get; set; }
    }
}
