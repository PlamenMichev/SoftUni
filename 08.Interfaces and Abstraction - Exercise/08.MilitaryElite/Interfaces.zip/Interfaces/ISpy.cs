﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _08.MilitaryElite
{
    public interface ISpy
    {
        int CodeNumber { get; set; }
    }
}
