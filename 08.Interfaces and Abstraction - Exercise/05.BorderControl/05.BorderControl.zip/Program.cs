﻿using System;
using System.Collections.Generic;

namespace _05.BorderControl
{
    class Program
    {
        static void Main(string[] args)
        {
            List<IIdiable> citizens = new List<IIdiable>();

            string input = Console.ReadLine();
            while(input != "End")
            {
                string[] tokens = input
                    .Split();
                string name = tokens[0];
                
                if (tokens.Length ==3)
                {
                    string id = tokens[2];
                    int age = int.Parse(tokens[1]);
                    var person = new Person(name, id, age);
                    citizens.Add(person);
                }
                else
                {
                    string id = tokens[1];
                    var robbot = new Robot(id, name);
                    citizens.Add(robbot);
                }

                input = Console.ReadLine();
            }

            string line = Console.ReadLine();

            foreach (var citizen in citizens)
            {
                if (citizen.EndsOn(line))
                {
                    Console.WriteLine(citizen.Id);
                }
            }
        }
    }
}
