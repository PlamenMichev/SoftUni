﻿namespace _05.BorderControl
{
    public interface IIdiable
    {
        string Id { get; }

        bool EndsOn(string end);
    }
}
