﻿namespace _04.Telephony
{
    public interface ICallable
    {
        string Call(string number);
    }
}
