﻿namespace _04.Telephony
{
    public interface IBrowseble
    {
        string Browse(string url);
    }
}
